class Cliente:

    def __init__(self, nombre, usuario, edad):
        self.nombre = nombre