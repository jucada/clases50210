from setuptools import setup

setup(
    name="paquete1",
    version="0.1"
)